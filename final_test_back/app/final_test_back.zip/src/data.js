const users = [
  {
    id: 1,
    name: 'Luca',
    login: 'lucamqf',
    password: 'KmA100x!',
    avatar: ''
  },
  {
    id: 2,
    name: 'Dayse',
    login: 'daysemorenah',
    password: 'Dayse773300',
    avatar: ''
  },
  {
    id: 3,
    name: 'Luigi',
    login: 'luweed',
    password: '15998Jack',
    avatar: ''
  }
];

module.exports = { users };